## Preparazione dei dati
In questa directory saranno presenti statistiche, immagini, text utili sui dati.
