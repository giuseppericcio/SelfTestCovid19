## Dati 
In questa directory sarà presente il dataset di progetto e altri file utili per la preparazione del dataset.
